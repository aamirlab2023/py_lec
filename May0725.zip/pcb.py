#!/usr/bin/env python3

a = [1, 2, 3, 4, 5, 6, 7, 8, 9]

for integer in a:
    if integer <= 3:
        pass
        print(f"The integer is: {integer:d}")
    elif integer <= 6:
        continue
        print(f"The integer is: {integer:d}")
    elif integer <= 9:
        break
        print(f"The integer is: {integer:d}")
    print(f"Execution count: {integer:d}")

"""
a = [2, 4, 6]
b = [0, 1, 3]

for i in range(len(a)):
    print(a[i]/b[i])

for i in range(len(a)):
    if b[i] == 0:
        pass
    else:
        print(a[i]/b[i])
"""
