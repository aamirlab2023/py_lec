#!/usr/bin/env python3

import random as random

print("Integers only between 1 and 100 inclusive")
for i in range(5):
    print(random.randint(1, 100))
print()

print("Real numbers between 0 inclusive and 1 exclusive")
for i in range(5):
    print(random.random())
print()

print("Real numbers between 0 inclusive and 10 exclusive")
for i in range(5):
    print(10*random.random())
print()

print("Real numbers between 0 inclusive and 100 exclusive")
for i in range(5):
    print(100*random.random())
print()
