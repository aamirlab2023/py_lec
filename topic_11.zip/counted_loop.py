#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Oct  4 18:24:42 2022

@author: aamir
"""

fahrenheit = [180.0, 187.7, 164.2, 192.6, 167.5, 157.3]

for f_temp in fahrenheit:
    c_temp = (5/9)*(f_temp - 32)
    print(c_temp)


# fahrenheit = [180.0, 187.7, 164.2, 192.6, 167.5, 157.3]
# celcius = []
# for f_temp in fahrenheit:
#     c_temp = (5/9)*(f_temp - 32)
#     celcius.append(c_temp)
# print(celcius)


# fahrenheit = [180.0, 187.7, 164.2, 192.6, 167.5, 157.3]
# print('Fahrenheit Temperature        Celcius Temperature')
# print('======================        ===================')
# for f_temp in fahrenheit:
#     print('{0:^22.2f}        {1:^19.2f}'.format(f_temp, (5/9)*(f_temp - 32)))