#!/usr/bin/env python3

masses = [10.3, 1.7, 9.4, 5.1, 12.1, 3.3]
velocities = [20.3, 5.7, 52.1, 32.4, 15.6, 21.9]

print(*enumerate(masses))
"""
print("Sr. No.    Masses (kg)")
print("=======    ===========")
for counter, values in enumerate(masses):
    print(f'{counter:<7d}    {values:<4.1f}')
# How to rectify serial number to start from 1?


print("Sr. No.    Mass (kg)    Velocity (m/s)")
print("=======    =========    ==============")
for counter, values in enumerate(masses):
    print(f'{counter+1:<7d}    {values:<9.1f}    {velocities[counter]}')


print("Sr. No.    Mass (kg)    Velocity (m/s)    Kinetic Energy (J)")
print("=======    =========    ==============    ==================")
for counter, values in enumerate(masses):
    print(f'{counter+1:<7d}    {values:<9.1f}', end = "    ")
    print(f'{velocities[counter]:<14.1f}', end = "    ")
    print(f'{0.5*values*velocities[counter]**2:.2f}')
"""
