#!/bin/bash

rm *.aux
rm *.log
rm *.nav
rm *.out
rm *.pdf
rm *.snm
rm *.toc
clear
pdflatex lecture_09.tex
