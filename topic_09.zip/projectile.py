#!/usr/bin/env python3
"""
    projectile.py - This program computes the maximum height reached by a
    projectile given the initial velocity and angle of launch.

    Copyright (C) 2024 Aamir Alaud Din

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <https://www.gnu.org/licenses/>.
"""


import math as m


# Initialize variables
init_vel = 20  # m/s
theta = 25  # degrees
grav_acc = 9.8  # m/s**2

# Convert angle in degrees to angle in radians
theta = (m.pi/180.0)*theta  # radians

# Compute time to  reach maximum height
time = init_vel*m.sin(theta)/grav_acc

# Compute maximum height of projectile
height = init_vel*m.sin(theta)*time - 0.5*grav_acc*time

# Print maximum height
print(f'Maximum height reached by projectile: {height:.2f} m')
