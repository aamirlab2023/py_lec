#raw_file = open("methane_coords.txt", "r")
#lines = raw_file.readline()
#raw_file.close()

#print(lines) # raw line
#print(lines.split()) # splitted line
#line = lines.split()
#for item in line:
#    print(item)

#print(lines.split()) # splitted line
#line = lines.split()
#for item in line:
#    for char in item:
#        print(char)

#raw_file = open("methane_coords.txt", "r")
#lines = raw_file.readlines()
#raw_file.close()

#second_last = lines[-2] # second last line in raw form
#print(second_last) # raw
#second_last = second_last.split()
#print(second_last) # splitted
#for item in second_last:
#    print(item)
#for item in second_last:
#    for char in item:
#        print(char)


#for line in lines:
    ##print(line) # raw data
    #line = line.split()
    #print(line)

#atom_name = []
#x_coord = []
#y_coord = []
#z_coord = []
#for line in lines:
#    line = line.split()
#    atom_name.append(line[0])
#    x_coord.append(float(line[1]))
#    y_coord.append(float(line[2]))
#    z_coord.append(float(line[3]))

#print(atom_name)
#print(x_coord)
#print(y_coord)
#print(z_coord)

#import math as m
# Bond Lengths
#c_coords = [x_coord[0], y_coord[0], z_coord[0]]
#print(c_coords)

#for i in range(1, 5):
#    print(f'C-H Bond Length: {m.sqrt((c_coords[0] - x_coord[i])**2 +
#(c_coords[1] - y_coord[i])**2 + (c_coords[2] - z_coord[i])**2):.4f}')

"""
methane_mol = open("methane_coords.txt", "r")
lines = methane_mol.readlines()
methane_mol.close()

atom_counter = 1
methane_out = open("methane_mol.mol2", "w")
methane_out.writelines("@<TRIPOS>MOLECULE\n")
methane_out.writelines("Methane Structure File\n")
methane_out.writelines(" 5 4 0 0 0\n")
methane_out.writelines("SMALL\n")
methane_out.writelines("GASTEIGER\n\n")
methane_out.writelines("@<TRIPOS>ATOM\n")
for line in lines:
    line = line.split()
    if line[0] == "Carbon":
        atom_symbol = "C"
        atom_type = "C.3"
    elif line[0] == "Hydrogen":
        atom_symbol = "H"
        atom_type = "H  "

    methane_out.writelines("    %d" % atom_counter)
    methane_out.writelines("  %s" % atom_symbol)
    methane_out.writelines("    %s" % line[1])
    methane_out.writelines("    %s" % line[2])
    methane_out.writelines("    %s" % line[3])
    methane_out.writelines("  %s" % atom_type)
    methane_out.writelines("  1")
    methane_out.writelines("  METHANE")
    methane_out.writelines("  0.000")
    methane_out.writelines("\n")
    atom_counter += 1

bond_counter = 1
methane_out.writelines("@<TRIPOS>BOND\n")
for i in range(4):
    methane_out.writelines("  %d" % bond_counter)
    methane_out.writelines("  1")
    atom_id = bond_counter + 1
    methane_out.writelines("  %d" % atom_id)
    methane_out.writelines("  1")
    methane_out.writelines("\n")
    bond_counter += 1
"""
