#!/usr/bin/env python3
"""
    temp_convert.py - This program contains functions to convert fahrenheit
    temperature to celcius temperature and vice versa. It also contains
    functions to convert celcius temperature to kelvin and vice versa.

    Copyright (C) 2024 Aamir Alaud Din

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <https://www.gnu.org/licenses/>.
"""


def fahrenheit2celcius(fahrenheit):
    """
    The function fahrenheit2celcius converts the fahrenheit temperature to
    celcius temperature. The function takes exactly one argument (fahrenheit
    temperature) and returns the celcius temperature.

    Syntax:
        celcius = fahrenheit2celcius(fahrenheit)

    Example:
        celcius = fahrenheit2celcius(180.0)
    """

    return (5/9)*(fahrenheit - 32)


def celcius2fahrenheit(celcius):
    """
    The function celcius2fahrenheit converts the celcius temperature to
    fahrenheit temperature. The function takes exactly one argument (celcius
    temperature) and returns the fahrenheit temperature.

    Syntax:
        fahrenheit = celcius2fahrenheit(celcius)

    Example:
        fahrenheit = celcius2fahrenheit(180.0)
    """

    return (5/9)*celcius + 32


def kelvin2celcius(kelvin):
    """
    The function kelvin2celcius converts the kelvin temperature to
    celcius temperature. The function takes exactly one argument (kelvin
    temperature) and returns the celcius temperature.

    Syntax:
        celcius = kelvin2celcius(kelvin)

    Example:
        celcius = kelvin2celcius(180.0)
    """

    return kelvin - 273.15


def celcius2kelvin(celcius):
    """
    The function celcius2kelvin converts the celcius temperature to
    kelvin temperature. The function takes exactly one argument (celcius
    temperature) and returns the kelvin temperature.

    Syntax:
        kelvin = celcius2kelvin(celcius)

    Example:
        kelvin = celcius2kelvin(180.0)
    """

    return celcius + 273.15
