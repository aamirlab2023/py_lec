#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Jun 25 20:07:43 2024

@author: aamir
"""

import numpy as np
import matplotlib.pyplot as plt

x = np.linspace(0, 6.29, 200)
y = np.sin(x)

plt.plot(x, y, '-k')
plt.show()